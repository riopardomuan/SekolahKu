import React from 'react'
import { StyleSheet, Text, View, Image } from 'react-native'
import { AntDesign } from '@expo/vector-icons';
export default function App () {
   return (
     <View style={styles.container}>
       <Text style={styles.text}> <AntDesign name="left" size={15} color="black" /> List Mata Pelajaran </Text>
    </View>   
   )
}

const styles = StyleSheet.create({
   container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'left',
   },

   text: {
    color: 'Black',
    fontSize: 20,
    padding: 10,

    back:{
    marginTop:10,
    marginLeft:20,
    height:10,
    weight:10,
      },
   },
})

