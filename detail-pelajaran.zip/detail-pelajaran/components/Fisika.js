import * as React from 'react';
import { Text, View, StyleSheet, Image, TextInput } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import {Feather} from '@expo/vector-icons';


export default function AssetExample() {
  return (
    <View style={styles.container}>

    <View style={styles.m}>
    <AntDesign name="left" size={20} color="black" />
    <Text style={styles.teks}>Detail Pelajaran</Text>
    </View>


    <View style={styles.box}>
    <Image source={require('../assets/info.png')} style={{width:70, height:70, marginTop:30, marginLeft:100,}}/>
    <Text style={styles.teks2}>Fisika</Text>
    <Image source={require('../assets/Line.png')} style={{width:280, height:2, marginTop:10}} />
    <Text style={styles.teks3}>Pengertian fisika yaitu berasal dari kata “physic” yang artinya yaitu alam. Jadi ilmu fisika yaitu sebuah ilmu pengetahuan dimana didalamnya mempelajari tentang sifat dan fenomena alam atau gejala alam dan seluruh interaksi yang terjadi didalamnya. Untuk mempelajari fenomena atau gejala alam, fisika menggunakan proses dimulai dari pengamatan, pengukuran, analisis dan menarik kesimpulan. Sehingga prosesnya lama dan berbuntut panjang, namun hasilnya bisa dipastikan akurat karena fisika termasuk ilmu eksak yang kebenarannya terbukti.</Text>
    </View>
    </View>
  );
}



const styles = StyleSheet.create({
  container: {
    paddingLeft:5,
    paddingRight:5,
    marginTop:5,
    marginBottom:5,
    flexDirection:'column'
  },
  m:{
    paddingLeft:10,
    paddingRight:5,
    marginTop:15,
    marginBottom:15,
    flexDirection:'row',
    width:325,
    height:50,
  },
  teks:{
    fontSize:18,
    marginLeft:20,
    marginTop:3,
    fontFamily:'Montserrat',
  },
  teks2:{
    fontSize:35,
    marginLeft:94,
    marginTop:15,
    fontFamily:'Poppins',
    fontWeight:'bold',
  },
  teks3:{
    fontSize:15,
    marginLeft:15,
    marginTop:10,
    fontFamily:'Poppins',
  },
  box:{
    width:280,
    height:430,
    marginLeft:15,
    marginRight:15,
    backgroundColor:'#EFF5FB',
    flexDirection:'column',
    borderRadius:20
  }
});
