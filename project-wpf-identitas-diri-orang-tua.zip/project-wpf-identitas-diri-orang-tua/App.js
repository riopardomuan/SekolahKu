import * as React from 'react';
import { Text, View, StyleSheet,ScrollView } from 'react-native';
import Constants from 'expo-constants';
import FormIdentitas from './components/UjiCoba'

export default function App() {
  return (
    <View style={ {marginTop:Constants.statusBarHeight} }>
   <ScrollView />
      <FormIdentitas />
    </View>
  );
}