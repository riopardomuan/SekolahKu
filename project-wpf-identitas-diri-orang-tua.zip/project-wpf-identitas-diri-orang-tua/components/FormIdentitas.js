import * as React from 'react';
import { Image, StyleSheet, View, Text, TextInput, Button, Pressable  } from 'react-native';
import { AntDesign } from '@expo/vector-icons'; 
import { Feather } from '@expo/vector-icons'; 

export default function FormIdentitas() {
  
  return (

    
    <View style={styles.m}>
        <View style={styles.main}>
      
        <Text style={styles.teks}>Identitas Orang Tua</Text>
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.form} placeholder="Nama Ayah"/>
        
        </View>
        
        <View style={styles.main3}>
        <TextInput style={styles.form} placeholder="Nama Ibu"/>
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.form} placeholder="Kerja Ayah"/>
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.form} placeholder="Kerja Ibu"/>
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.form} placeholder="Tempat & Tanggal Lahir Ayah"/>
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.form} placeholder="Tempat & Tanggal Lahir Ibu"/>
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.form} placeholder="Alamat"/>
        </View>
<View style={styles.main3}>
        <TextInput style={styles.form} placeholder="ID_Dokumen"/>
        </View>
        <View style={styles.main3}>
          <Pressable style={styles.button}>
            <Text style={styles.text}>Daftar</Text>
          </Pressable>
        </View>
    </View>

    
  );
}



const styles = StyleSheet.create({
   m:{
    paddingLeft:15,
    paddingRight:15,
    marginTop:23,
    marginBottom:15,
    flexDirection:'column'
  },
  main:{
    paddingLeft:5,
    paddingRight:15,
    marginTop:23,
    marginBottom:15,
    flexDirection:'column'
  },
   main3:{
    paddingLeft:10,
    marginTop:30,
    marginBottom:15,
    flexDirection:'row',
    paddingRight:15
  },
   
  teks:{
    fontSize:22,
    marginLeft:10,
    marginTop:20,
    fontFamily:'Montserrat',
  },
 
  
 form:{
  width: 325,
  height: 40,
  borderBottomWidth:1,
  flex:1,
  fontFamily:'Montserrat',
  marginLeft:5,
  fontSize:15,
},
button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 32,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: '#BFE8FC',
    width: 325,
    height: 40
  },
  text: {
    fontSize: 15,
    lineHeight: 21,
    letterSpacing: 0.25,
    color: 'black',
    fontFamily:'Montserrat',
  },

});
