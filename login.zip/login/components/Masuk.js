import * as React from 'react';
import { Image, StyleSheet, View, Text, TextInput, Button, Pressable  } from 'react-native';
import { AntDesign } from '@expo/vector-icons'; 
import { Feather } from '@expo/vector-icons'; 

export default function AssetExample() {
  
  return (
    <View style={styles.m}>
        <AntDesign name="arrowleft" size={24} color="black" />

        <View style={styles.main2}>
        <Image source={require('../assets/logo.png')} style={{width:104, height:98}} />
        </View>

        <View style={styles.main}>
        <Text style={styles.teks}>Masuk</Text>
        <Image source={require('../assets/garis.png')} style={{marginLeft:10}} />
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.formCari} placeholder="Email"/>
        </View>

        <View style={styles.main3}>
        <TextInput style={styles.formCari} placeholder="Kata Sandi"/>
        <Feather name="eye-off" size={24} color="black" style={{
        position:'absolute', marginLeft:290}} />
        </View>

        <View style={styles.main3}>
          <Pressable style={styles.button}>
            <Text style={styles.text}>Login</Text>
          </Pressable>
        </View>

        <View style={styles.main4}>
        <Text style={styles.teks2}>Tidak Punya Akun?</Text>
        <Text style={styles.teks3}>DAFTAR</Text>
        </View>

    </View>

    
  );
}


const styles = StyleSheet.create({
   m:{
    paddingLeft:15,
    paddingRight:15,
    marginTop:23,
    marginBottom:15,
    flexDirection:'column'
  },
  main:{
    paddingLeft:5,
    paddingRight:15,
    marginTop:23,
    marginBottom:15,
    flexDirection:'column'
  },
  main2:{
    paddingLeft:130,
    marginTop:50,
    marginBottom:15,
    flexDirection:'column',
  },
   main3:{
    paddingLeft:10,
    marginTop:30,
    marginBottom:15,
    flexDirection:'row',
    paddingRight:15
  },
   main4:{
    paddingLeft:3,
    marginTop:10,
    marginBottom:15,
    flexDirection:'row',
    paddingRight:10,
    justifyContent:'center'
  },
  teks:{
    fontSize:20,
    marginLeft:10,
    marginTop:20,
    fontFamily:'Montserrat',
  },
  teks2:{
    fontSize:13,
    marginLeft:10,
    marginTop:20,
    fontFamily:'Montserrat',
  },
    teks3:{
    fontSize:13,
    marginLeft:10,
    marginTop:20,
    fontFamily:'Montserrat',
    color :'#BFE8FC',
    fontWeight :'bold'
  },
 formCari:{
  width: 325,
  height: 40,
  borderBottomWidth:1,
  flex:1,
  fontFamily:'Montserrat',
  marginLeft:5,
  fontSize:20,
},
button: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 32,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: '#BFE8FC',
    width: 325,
    height: 40
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    letterSpacing: 0.25,
    color: 'black',
    fontFamily:'Montserrat',
  },

});
