import React, {useEffect, useState} from "react";
import { AntDesign } from '@expo/vector-icons'; 
import{
    Text,
    View,
    StyleSheet,
    Image,
    ActivityIndicator,
} from "react-native";
import {Hitam5} from "./Warna"


export default function Promo(){
const [isLoading,setLoading]= useState(true);
const [data,setData]= useState([]);
const getGojekPromo = async ()=> {
    try{
        const response = await fetch(
            "https://15de-113-212-122-130.ngrok.io/api/jurusans",
            {headers: new Headers({"ngrok-skip-browser-warning": "69420",}),
    }

        );
        const json = await response.json();
        console.log(json.data.data)
        setData(json.data.data);
        console.log(data);
    }catch (error){
        console.error(error);
    }finally{
        setLoading(false);
    }
};
useEffect(() => {
    getGojekPromo();
},[])

const CardPromo = (props)=>{
    return(
        <View 
        style={{
            height:40,
            borderRadius:15,
            borderWidth:1,
            borderColor:Hitam5,
            paddingLeft: 10,
            paddingTop: 8
        }}
        
        >
            <View>
</View>
<View style={{flex:1}}>
    <Text 
    style={{
        fontSize:16,
        fontWeight : "bold",
    }} 
    >
        {props.jurusan}
    </Text>
 </View>
        </View>
        
    );
};
if(isLoading){
    <ActivityIndicator/>;
}else{
    return(
        <View style={Styles.main}>
            {
                data.map((val)=>{
                    return(
                        <CardPromo jurusan={val.jurusan} />
                    )
                })
            }
            
        </View>
    );
}}

const Styles = StyleSheet.create({
    main:{
        justifyContent : "center",
        padding:16,
    },
});