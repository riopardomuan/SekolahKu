import * as React from 'react';
import {StyleSheet, View, Text, TextInput, Button, Pressable  } from 'react-native';
 
import { Feather } from '@expo/vector-icons'; 

export default function AssetExample() {

  
  return (
    <View style={styles.m}>
        <View style={styles.main3}>
        <TextInput style={styles.formCari} placeholder="Ilmu Pengetahuan Alam"/>
    </View>

    <View style={styles.main3}>
        <TextInput style={styles.formCari} placeholder="Ilmu Pengetahuan Sosial"/>
    </View>

    <View style={styles.main3}>
        <TextInput style={styles.formCari} placeholder="Bahasa dan Sastra"/>
    </View>
  </View>
    
  );
}

const styles = StyleSheet.create({
   
 
   main3:{
    paddingLeft:10,
    marginTop:30,
    marginBottom:15,
    flexDirection:'row',
    paddingRight:15
  },
  
  
 formCari:{
  width: 325,
  height: 40,
  borderBottomWidth:1,
  flex:1,
  fontFamily:'Montserrat',
  marginLeft:5,
  fontSize:20,
},
});
