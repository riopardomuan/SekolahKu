import * as React from 'react';
import { Text, View, StyleSheet, TextInput, Image } from 'react-native';
import {Hitam5, Hitam4} from './Warna'
import { Feather } from '@expo/vector-icons';
export default function Search() {
  return (
    <View style={styles.main}> 
    <Feather name="search" size={18} color="black" style={{
      position:'absolute',
      marginLeft:20,
      alignSelf:'center'
    }} />
<TextInput style={styles.formCari} placeholder="Pencarian"/>
    </View>
  );
}
const styles = StyleSheet.create({
main: {
  paddingLeft:15,
  paddingRight:15,
  marginTop:23,
  marginButtom:15,
  flexDirection:'row'
},
formCari:{
  height:35,
  borderRadius:30,
  borderWidth:1,
  borderColor:Hitam5,
  color:Hitam4,
  paddingLeft:40,
  flex:1
}
});