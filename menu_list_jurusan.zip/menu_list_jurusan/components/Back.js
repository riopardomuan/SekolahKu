import React from 'react'
import { StyleSheet, Text, View, Image } from 'react-native'
import { AntDesign } from '@expo/vector-icons';
export default function App () {
   return (
     <View style={styles.main}>
        <Text style={styles.teks}><AntDesign name="left" size={20} color="black" /> List Jurusan</Text>
        </View> 
   )
}

const styles = StyleSheet.create({
  main:{
    paddingLeft:5,
    paddingRight:15,
    marginTop:23,
    marginBottom:15,
    flexDirection:'column'
  },
})

