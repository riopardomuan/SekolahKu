import * as React from 'react';
import { Text, View, StyleSheet, Image, TextInput } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import {Feather} from '@expo/vector-icons';


export default function AssetExample() {
  return (
    <View style={styles.container}>

    <View style={styles.m}>
    <AntDesign name="left" size={20} color="black" />
    <Text style={styles.teks}>Sekolahku</Text>
    </View>


    <View style={styles.box}>
    <Image source={require('../assets/favicon.png')} style={{width:70, height:70, marginTop:30, marginLeft:100,}}/>
    <Text style={styles.teks2}>Sekolahku</Text>
    <Image source={require('../assets/favicon.png')} style={{width:280, height:2, marginTop:10}} />
    <Text style={styles.teks3}>Sekolahku adalah applikasi yang dirancang untuk memudahkan pengguna agar dapat melihat informasi seputar SMA Negeri 1 Telaga Biru dan melakukan pendaftaran calon siswa baru dimana saja dan kapan saja.</Text>
      <Text style={styles.teks3}>Pengembang kelompok 4: </Text>
      <Text style={styles.teks3}>1. Rio Pardomuan Marpaung </Text>
      <Text style={styles.teks3}>2. Feby Cahyani Putri </Text>
      <Text style={styles.teks3}>3. Sarah Azizah Wardah </Text>
      <Text style={styles.teks3}>4. Mickel Fauzan Mendrofa </Text>
      <Text style={styles.teks3}>5. Amirul</Text>
      <Text style={styles.teks3}>6. Choir Syahputra</Text>
      <Text style={styles.teks3}>7. Sekar Anggaraini</Text>
    </View>
    </View>
  );
}



const styles = StyleSheet.create({
  container: {
    paddingLeft:5,
    paddingRight:5,
    marginTop:5,
    marginBottom:5,
    flexDirection:'column'
  },
  m:{
    paddingLeft:10,
    paddingRight:5,
    marginTop:15,
    marginBottom:15,
    flexDirection:'row',
    width:325,
    height:50,
  },
  teks:{
    fontSize:18,
    marginLeft:20,
    marginTop:3,
    fontFamily:'Montserrat',
  },
  teks2:{
    fontSize:35,
    marginLeft:58,
    marginTop:15,
    fontFamily:'Poppins',
    fontWeight:'bold',
  },
  teks3:{
    fontSize:15,
    marginLeft:15,
    marginTop:10,
    fontFamily:'Poppins',
  },
  box:{
    width:280,
    height:430,
    marginLeft:15,
    marginRight:15,
    backgroundColor:'#EFF5FB',
    flexDirection:'column',
    borderRadius:20
  }
});
