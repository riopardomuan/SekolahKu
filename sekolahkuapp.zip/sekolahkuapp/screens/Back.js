import React from 'react'
import { StyleSheet, Text, View, Image } from 'react-native'
import { AntDesign } from '@expo/vector-icons';
export default function App () {
   return (
     <View style={styles.container}>
       <Text style={styles.text}> </Text>
       <AntDesign name="left" size={24} color="black" />
    </View>
    
    
   )
}

const styles = StyleSheet.create({
   container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'left',
   },

   text: {
    color: 'Black',
    fontSize: 20,
    padding: 10,

    back:{
    marginTop:10,
    marginLeft:20,
    height:10,
    weight:10,
  },

   },
})