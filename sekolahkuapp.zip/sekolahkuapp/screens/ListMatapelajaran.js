import * as React from 'react';
import { Image, StyleSheet, View, Text, TextInput, Button, Pressable  } from 'react-native';
 
import { Feather } from '@expo/vector-icons'; 

export default function AssetExample() {
  
  return (
    <View style={styles.m}>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Fisika.png')}/>
        <TextInput style={styles.formCari} placeholder="Fisika"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Kimia.png')}/>
        <TextInput style={styles.formCari} placeholder="Kimia"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Biologi.png')}/>
        <TextInput style={styles.formCari} placeholder="Biologi"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Economic.png')}/>
        <TextInput style={styles.formCari} placeholder="Ekonomi"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Sosiologi.png')}/>
        <TextInput style={styles.formCari} placeholder="Sosiologi"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Sejarah.png')}/>
        <TextInput style={styles.formCari} placeholder="Sejarah"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Indo.png')}/>
        <TextInput style={styles.formCari} placeholder="Bahasa Indonesia"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Inggris.png')}/>
        <TextInput style={styles.formCari} placeholder="Bahasa Inggris"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Math.png')}/>
        <TextInput style={styles.formCari} placeholder="Matematika"/>
        </View>

        <View style={styles.main3}>
        <Image style={styles.gambar} source={require('../assets/Agama.png')}/>
        <TextInput style={styles.formCari} placeholder="Agama"/>
        </View>
    </View> 
  );
}

const styles = StyleSheet.create({
   main3:{
    paddingLeft:10,
    marginTop:30,
    marginBottom:15,
    flexDirection:'row',
    paddingRight:15
  },

 formCari:{
  width: 325,
  height: 40,
  borderBottomWidth:1,
  flex:1,
  fontFamily:'Montserrat',
  marginLeft:5,
  fontSize:20,
},

});
