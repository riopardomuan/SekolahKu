import * as React from 'react';
import { Image, StyleSheet, View, Text, TextInput, Button, Pressable  } from 'react-native';
import { AntDesign } from '@expo/vector-icons'; 
import { Feather } from '@expo/vector-icons'; 

export default function Register() {
  
  return (
    <View style={styles.m}>
        <AntDesign name="arrowleft" size={24} color="black" />
        <View style={styles.main}>
        <Image source={require('../assets/Globe.png')} style={{width:206, height:201, marginTop: 100}} />
        </View>
          <View style={styles.styleText}>
            <Text style={{
              fontSize: 14,
              opacity: 0.4,
              textAlign: 'center',
              lineHeight: 28,
              paddingLeft: 50,
              paddingRight: 50,
              }}>Silahkan  masuk terlebih dahulu atau daftar untuk memulai aplikasi
              </Text>
          </View>
        <View style={styles.main2}>
          <Pressable style={styles.button1}>
            <Text style={styles.text}>Masuk</Text>
          </Pressable>
        </View>
        <View style={styles.main3}>
          <Pressable style={styles.button2}>
            <Text style={styles.text}>Daftar</Text>
          </Pressable>
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
   m:{
    paddingLeft:15,
    paddingRight:15,
    marginTop:23,
    marginBottom:15,
    flexDirection:'column'
  },
  main:{
    marginTop:50,
    marginBottom:15,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection:'column',
  },
  main2:{
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom:15,
    flexDirection:'row',
    paddingTop: 100,
  },
   main3:{
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom:15,
    flexDirection:'row',
  },

button1: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 32,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: '#BFE8FC',
    width: 325,
    height: 40,
  },
  button2: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 32,
    borderRadius: 10,
    elevation: 3,
    backgroundColor: '#ECEDEE',
    width: 325,
    height: 40
  },
  text: {
    fontSize: 16,
    lineHeight: 21,
    letterSpacing: 0.25,
    color: 'black',
    fontFamily:'Montserrat',
  },
  styleText: {
    paddingTop: 20,
    paddingBottom: 50,
  },

});