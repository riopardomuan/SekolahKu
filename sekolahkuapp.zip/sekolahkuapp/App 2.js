import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import Register from './screens/Register'



export default function App() {
  return (
    <View style={ {marginTop:Constants.statusBarHeight} }>
      <Register />
      
    </View>
  );
}