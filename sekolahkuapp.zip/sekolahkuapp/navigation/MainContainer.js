import * as React from 'react';
import {  DefaultTheme, NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';
import HomeScreen from './screens/HomeScreen';
import DetailsScreen from './screens/DetailsScreen';
import SettingsScreen from './screens/SettingsScreen';

const homeName = "Beranda";
const detailsName = "Daftar";
const settingsName = "Profil";
const Tab = createBottomTabNavigator();

const navTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: 'transparent',
  },
};

function MainContainer() {
  return (
    <NavigationContainer theme={navTheme}>
      <Tab.Navigator
        initialRouteName={homeName}
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            let rn = route.name;

            if (rn === homeName) {
              iconName = focused ? 'home' : 'home-outline';

            } else if (rn === detailsName) {
              iconName = focused ? 'list' : 'add-outline';

            } else if (rn === settingsName) {
              iconName = focused ? 'settings' : 'people-outline';
            }
            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
        tabBarOptions={{
          activeTintColor: '#1A814F',
          inactiveTintColor: 'grey',
          labelStyle: { paddingBottom: 10, fontSize: 10 },
          style: { padding: 10, height: 70}
        }}>
        
        <Tab.Screen name={homeName} component={HomeScreen} options={{ headerShown:false }} />
        <Tab.Screen name={detailsName} component={DetailsScreen} options={{ headerShown:false }} />
        <Tab.Screen name={settingsName} component={SettingsScreen} options={{ headerShown:false }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default MainContainer;