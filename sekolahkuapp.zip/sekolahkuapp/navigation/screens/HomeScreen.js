import * as React from 'react';
import { View } from 'react-native';
import Constants from 'expo-constants';

import Profile from './components/Header';
import Search from './components/Search';
import Banner from './components/Banner';
import Menu from './components/Menu';
import Berita from './components/BeritaTerbaru';

export default function HomeScreen() {
  return (
    <View style={{marginTop:Constants.statusBarHeight, backgroundColor: '#FFFFFF'}}>
        <Profile />
        <Search />
        <Banner />
        <Menu />
        <Berita />
    </View>
  );
}