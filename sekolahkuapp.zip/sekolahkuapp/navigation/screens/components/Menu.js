import * as React from 'react';
import { Text, View, StyleSheet, Image, FlatList } from 'react-native';
import {Hitam1} from './Warna'
export default function MenuUtama() {
  const listMenu= [
    {
      'icon':require('../../../assets/Students.png'),
      'text':'Calon Siswa'
    },
    {
      'icon':require('../../../assets/Teacher.png'),
      'text':'Kelas'
    },
    {
      'icon':require('../../../assets/Science.png'),
      'text':'Jurusan'
    },
    {
      'icon':require('../../../assets/Professor.png'),
      'text':'Guru'
    },
    {
      'icon':require('../../../assets/Other.png'),
      'text':'Lainnya'
    }
  ]

  const ItemMenu = (props)=>{
    return(
      <View style={{ flex:1, marginLeft:15 }}>
        <Image source={props.icon}  resizeMode="center" style={{ backgroundColor:props.warna, width:30, height:30 }} />
        <Text style={{marginTop:2}}>{props.judul}</Text>
      </View>
    )
  }
  return (
    <View style={styles.main}>
    <Text style={{ fontSize:18, fontWeight:'650', color:Hitam1, paddingLeft: 15 }}>Menu</Text>
      <FlatList horizontal={false} numColumns={4} data={listMenu} renderItem={({item}) => <ItemMenu judul={item.text} icon={item.icon} />} 
      style={{ paddingTop: 10 }} />
    </View>
  );
}
const styles = StyleSheet.create({
   main:{
    justifyContent:'center',
    marginTop:10,
  },
});