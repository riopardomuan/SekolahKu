import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import {Hijau2,Biru1} from './Warna'
import { AntDesign } from '@expo/vector-icons'; 
import { Entypo } from '@expo/vector-icons'; 
import { Ionicons } from '@expo/vector-icons'; 
export default function  Banner() {
  return (
    <View style={styles.main}>
      <BannerCard />
    </View>
  );
}
const styles = StyleSheet.create({
  main:{
    justifyContent:'center',
    paddingLeft:15,
    paddingRight:15,
  },
});

const BannerCard=()=> {
  return (
    <>
    <View style={{
      alignSelf:'baseline',
      borderRadius:8
    }}>
    <Image source={require('../../../assets/banner.png')} style={{ height: 119, width: 310 }} />
    </View>
    </>
  )
}