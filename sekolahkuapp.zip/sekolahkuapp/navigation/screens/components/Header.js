import * as React from 'react';
import { Text, View, StyleSheet, TextInput,Image } from 'react-native';
import {Hitam5,Hitam4} from './Warna'
import { Feather } from '@expo/vector-icons'; 
export default function Search() {
  return (
    <View style={styles.main}>
        <Text size={24} style={{ position:'absolute', alignSelf:'center', fontWeight:'700', fontSize: 20 }} > Kelompok 4 </Text>
        <Text style={{ fontWeight:'500', position:'absolute', fontSize: 14 }}> Selamat Datang </Text>
        <Image source={require('../../../assets/avatar.png')}  style={{ height: 50, width: 50, marginLeft: 255 }}/>
    </View>
  );
}
const styles = StyleSheet.create({
  main:{
    paddingLeft:15,
    paddingRight:15,
    marginTop:20,
    flexDirection:'row'
  },
});