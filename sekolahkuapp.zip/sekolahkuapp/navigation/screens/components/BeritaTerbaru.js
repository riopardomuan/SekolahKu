import * as React from 'react';
import { Text, View, StyleSheet, Image, FlatList } from 'react-native';
import {Hitam1} from './Warna'
export default function MenuUtama() {
  const listMenu= [
    {
      'icon':require('../../../assets/berita.jpg'),
      'text':'Kondisi Ruang Kelas',
      'isi':'Kelas XI IPA 1 sedang belajar mengenai ancaman COVID-19.'
    },
    {
      'icon':require('../../../assets/berita.jpg'),
      'text':'Kondisi Ruang Kelas',
      'isi':'Kelas XI IPA 1 sedang belajar mengenai ancaman COVID-19.'
    },
    {
      'icon':require('../../../assets/berita.jpg'),
      'text':'Kondisi Ruang Kelas',
      'isi':'Kelas XI IPA 1 sedang belajar mengenai ancaman COVID-19.'
    }
  ]

  const ItemMenu = (props)=>{
    return(
      <View style={{ justifyContent:'space-around',flex:1, marginLeft:15 }}>
        <View style={{ borderWidth: 1, borderRadius: 15, borderColor: '#E8E8E8', width: 250}}>
          <View style={{ position: "relative"  }}>
            <Image
              source={props.icon}
              style={{ height: 120, width: "100%", borderTopLeftRadius: 15, borderTopRightRadius: 15 }}
            ></Image>
            <View
              style={{
                width: "100%",
                height: "100%",
                position: "absolute",
                top: 0,
                left: 0,
                backgroundColor: "black",
                opacity: 0.2,
                borderRadius: 6,
              }}
            ></View>
            <View
              style={{
                height: 15,
                width: 55,
                position: "absolute",
                top: 16,
                left: 16
              }}
            >
            </View>
          </View>
          <View style={ styles.isiBerita } >
            <Text style={{ fontSize: 16, fontWeight: "bold", color: "#1C1C1C" }}>
              {props.judul}
            </Text>
            <Text style={{ fontSize: 14, color: "#7A7A7A", marginBottom: 11 }}>
              {props.isi}
            </Text>
          </View>
        </View> 
      </View>
    )
  }
  return (
    <View style={styles.main}>
    <Text style={{ fontSize:18, fontWeight:'650', color:Hitam1, paddingLeft: 15 }}>Berita Terbaru</Text>
      <FlatList horizontal={true}
      data={listMenu} renderItem={({item}) => <ItemMenu judul={item.text} icon={item.icon} isi={item.isi} />} 
      style={{ paddingTop: 10 }} showsHorizontalScrollIndicator={false} />
    </View>
  );
}
const styles = StyleSheet.create({
   main:{
    justifyContent:'center',
    marginTop:10,
  },
  isiBerita:{
    paddingTop: 16,
    paddingBottom: 10,
    borderBottomColor: "#E8E9ED",
    borderBottomWidth: 1,
    paddingHorizontal: 16,
  },
});