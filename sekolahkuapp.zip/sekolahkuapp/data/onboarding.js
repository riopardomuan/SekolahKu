export default data = [
    {
        _id: '1',
        title: 'Tut Wuri Handayani',
        description: 'Dari belakang, seorang guru harus bisa memberikan dorongan dan arahan.',
        img: require('../assets/images/logoTWH.png')
    },
    {
        _id : '2',
        title: 'Organisasi Siswa Intra Sekolah',
        description: 'Menumbuhkan rasa persatuan antar siswa.',
        img: require('../assets/images/logoOSIS.png')
    },
    {
      _id : '3',
      title: 'SMA Negeri 1 Telaga Biru',
      description: 'SMA Negeri terbaik di Gorontalo.',
      img: require('../assets/images/logoSMA.png')
    },
]