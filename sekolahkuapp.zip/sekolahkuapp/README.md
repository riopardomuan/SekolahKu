# Requirements

Remember to install these:

- yarn add @react-navigation/native

- expo install react-native-gesture-handler react-native-reanimated react-native-screens react-native-safe-area-context @react-native-community/masked-view

- yarn add @react-navigation/stack

- yarn add @react-navigation/bottom-tabs
