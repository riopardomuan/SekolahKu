import React, {useEffect, useState} from "react";

import { AntDesign } from '@expo/vector-icons';
import {Feather} from '@expo/vector-icons';
import{
    Text,
    View,
    StyleSheet,
    Image,
    ActivityIndicator,
    TextInput
} from "react-native";


export default function Promo(){
const [isLoading,setLoading]= useState(true);
const [data,setData]= useState([]);
const getGojekPromo = async ()=> {
    try{
        const response = await fetch(
            "https://b370-113-212-122-130.ngrok.io/api/siswas"

        );
        const json = await response.json();
        console.log(json.data.data)
        setData(json.data.data);
    }catch (error){
        console.error(error);
    }finally{
        setLoading(false);
    }
};
useEffect(() => {
    getGojekPromo();
},[])

const CardPromo = (props)=>{
    return(
        <View >

      
      <View style={{backgroundColor: 'white',
    marginTop: 15,
    borderRadius: 20,
    marginRight:10,
    marginLeft:10,}}>
        <View style={{ flexDirection: 'column' }}>
        <Text style={{marginTop: 15, 
    fontSize:15, 
    fontWeight:'bold'}}>ID Orang Tua : {props.id_ortu}
</Text>
          <View style={{ flexDirection: 'row' }}>
            <Text style={{marginTop: 15, 
    fontSize:15, 
    fontWeight:'bold'}}>ID Bayar : {props.id_bayar}
</Text>
          </View>
          
          <View>
            <Text style={{marginTop: 15, 
    fontSize:15, 
    fontWeight:'bold'}}>ID Jurusan : {props.id_jurusan}
</Text>
          </View>
          <View>
            <Text style={{marginTop: 15, 
    fontSize:15, 
    fontWeight:'bold'}}>Nama : {props.nama}
</Text>
          </View>
          <View>
            <Text style={{marginTop: 15, 
    fontSize:15, 
    fontWeight:'bold'}}>Jenis Kelamin : {props.id_doc}
</Text>
          </View>
          <View>
            <Text style={{marginTop: 15, 
    fontSize:15, 
    fontWeight:'bold'}}>TTL : {props.ttl}
</Text>
          </View>
          <View>
            <Text style={{marginTop: 15, 
    fontSize:15, 
    fontWeight:'bold'}}>Alamat : {props.alamat}
</Text>
<Image source={require('../assets/Line.png')} />
          </View>
        </View>
      </View>
    </View>
  );
};
if(isLoading){
    <ActivityIndicator/>;
}else{
    return(
        <View style={Styles.container}>
        <View style={{ flexDirection: 'row',width:'100%'}}>
      </View>
      <View style={Styles.m}>
    <AntDesign name="left" size={20} color="black" />
    <Text style={Styles.teks}>List Calon Siswa</Text>
    </View>
    <View style={Styles.m}>
    
    <TextInput style={Styles.formCari} placeholder="Pencarian"/>
    <Feather name="search" size={20} color="black" style={{
        position:'absolute',
        marginLeft:25,
        alignSelf:'center'
      }} />
    </View>
            {
                data.map((val)=>{
                    return(
                        <CardPromo
        id_ortu={val.id_ortu}
        id_bayar={val.id_bayar}
        id_jurusan={val.id_jurusan}
        nama={val.nama}
        id_doc={val.id_doc}
        ttl={val.ttl}
        alamat={val.alamat}
        />
                    )
                })
            }

            
            
        </View>
    );
}}

const Styles = StyleSheet.create({
    main:{
        justifyContent : "center",
        padding:16,
    },
    container: {
    paddingLeft:5,
    paddingRight:5,
    marginTop:50,
    marginBottom:5,
    flexDirection:'column'
  },
  m:{
    paddingLeft:10,
    paddingRight:5,
    marginTop:15,
    marginBottom:15,
    flexDirection:'row'
  },
  teks:{
    fontSize:20,
    marginLeft:20,
    marginTop:0,
    fontFamily:'Montserrat',
  },
  formCari:{
  height:35,
  borderRadius:10,
  paddingLeft:40,
  marginLeft:2,
  marginRight:7,
  flex:1,
  width:325,
  height:50,
  backgroundColor : '#EFF5FB'
  
}
});