import { StatusBar, } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { FlatList, StyleSheet, Text, View, TouchableOpacity, ActivityIndicator, SafeAreaView, Platform } from 'react-native';
import { Surface, Title, TextInput } from 'react-native-paper';
import ModalView from './src/components/ModalView';
import PostCardItem from './src/components/PostCardItem';

// update this url -> "<new_ngrok_host_url>/posts"
const url = 'https://8a84-113-212-122-130.ngrok.io/api/kelass'

const headers = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
};

export default function App() {
  const [data, setData] = useState([]);
  const [visible, setVisible] = useState(false);
  const [kelas, setkelas] = useState('');
  const [id_wali_kelas, setid_wali_kelas] = useState('');
  const [postId, setPostId] = useState(0);
  const [loading, setLoading] = useState(false);

  const getPosts = async ()=> {
    try{
        const response = await fetch(
            "https://9249-113-212-122-130.ngrok.io/api/kelass",
            {headers: new Headers({
        "ngrok-skip-browser-warning": "69420",
      }),
    }

        );
        const json = await response.json();
        console.log(json.data.data)
        setData(json.data.data);
    }catch (error){
        console.error(error);
    }finally{
        setLoading(false);
    }
};

  const addPost = (kelas, id_wali_kelas) => {
    fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify({
        "kelas": kelas,
        "id_wali_kelas": id_wali_kelas,
      })
    }).then((res) => res.json())
      .then(resJson => {
        console.log('post:', resJson)
        updatePost()
      }).catch(e => { console.log(e) })
  }

  const editPost = (postId, kelas, id_wali_kelas) => {
    fetch(url + `/${postId}`, {
      method: "PUT",
      headers,
      body: JSON.stringify({
        "id_wali_kelas": id_wali_kelas,
        "kelas": kelas,
      })
    }).then((res) => res.json())
      .then(resJson => {
        console.log('updated:', resJson)
        updatePost()
      }).catch(e => { console.log(e) })
  }

  const deletePost = (postId) => {
    fetch(url + `/${postId}`, {
      method: "DELETE",
      headers,
    }).then((res) => res.json())
      .then(resJson => {
        console.log('delete:', resJson)
        getPosts()
      }).catch(e => { console.log(e) })
  }

  const updatePost = () => {
    getPosts()
    setVisible(false);
    setid_wali_kelas('')
    setkelas('')
    setPostId(0)
  }

  const edit = (id, kelas, id_wali_kelas) => {
    setVisible(true)
    setPostId(id)
    setkelas(kelas)
    setid_wali_kelas(id_wali_kelas)
  }

  useEffect(() => {
    getPosts();
  }, [])

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      <Surface style={styles.header}>
        <Title>Daftar Kelas</Title>
        <TouchableOpacity style={styles.button} onPress={() => setVisible(true)}>
          <Text style={styles.buttonText}>Tambah Kelas</Text>
        </TouchableOpacity>
      </Surface>
      <FlatList
        data={data}
        keyExtractor={(item, index) => item.id + index.toString()}
        refreshing={loading}
        onRefresh={getPosts}
        renderItem={({ item }) => (
          <PostCardItem
            kelas={item.kelas}
            id_wali_kelas={item.id_wali_kelas}
            onEdit={() => edit(item.id, item.kelas, item.id_wali_kelas)}
            onDelete={() => deletePost(item.id)}
          />
        )}
      />
      <ModalView
        visible={visible}
        kelas="Tambah Kelas"
        onDismiss={() => setVisible(false)}
        onSubmit={() => {
          if (postId && kelas && id_wali_kelas) {
            editPost(postId, kelas, id_wali_kelas)
          } else {
            addPost(kelas, id_wali_kelas)
          }
        }}
        cancelable
      >
        <TextInput
          label="kelas"
          value={kelas}
          onChangeText={(text) => setkelas(text)}
          mode="outlined"
        />
        <TextInput
          label="id_wali_kelas"
          value={id_wali_kelas}
          onChangeText={(text) => setid_wali_kelas(text)}
          mode="outlined"
        />
      </ModalView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  header: {
    marginTop: Platform.OS === 'android' ? 24 : 0,
    padding: 16,
    elevation: 2,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  button: {
    padding: 10,
    borderRadius: 20,
    backgroundColor: 'steelblue',
  },
  buttonText: {
    color: 'white'
  },
});
